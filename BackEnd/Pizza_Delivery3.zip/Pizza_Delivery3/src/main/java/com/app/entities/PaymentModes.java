package com.app.entities;

public enum PaymentModes {
COD,CREDIT_CARD,DEBIT_CARD,UPI,NETBANKING
}
