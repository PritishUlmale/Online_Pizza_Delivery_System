package com.app.service;

import com.app.entities.Category;

public interface ICategoryService {
	
public Category addCategory(Category cat);

}
